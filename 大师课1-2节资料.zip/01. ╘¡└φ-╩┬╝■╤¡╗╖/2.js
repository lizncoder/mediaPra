setTimeout(function () {
  setTimeout(function () {
    setTimeout(function () {
      setTimeout(function () {
        setTimeout(function () {
          setTimeout(function () {
            setTimeout(function () {
              setTimeout(function () {
                setTimeout(function () {}, 4);
              }, 4);
            }, 4);
          }, 4);
        }, 0);
      }, 0);
    }, 0);
  }, 0);
}, 0);
